import React from 'react';
import { Link } from 'react-router-dom';

function Footer() {
    return (
        <footer className="footer bg-dark">
            <div className="footer-middle">
                <div className="container">
                    <div className="footer-ribbon bg-primary text-white ls-10">
                        Get in touch
                    </div>

                    <div className="row">
                        <div className="col-lg-3 col-md-4">
                            <div className="widget">
                                <h4 className="widget-title">Contact Info</h4>
                                <ul className="contact-info">
                                    <li>
                                        <span className="contact-info-label">Address</span>123 Street Name, City, England
                                    </li>
                                    <li>
                                        <span className="contact-info-label">Phone</span>Toll Free <Link to="tel:">(123) 456-7890</Link>
                                    </li>
                                    <li>
                                        <span className="contact-info-label">Email</span> <Link to="mailto:mail@example.com">mail@example.com</Link>
                                    </li>
                                    <li>
                                        <span className="contact-info-label">Working Days/Hours</span>
                                        Mon - Sun / 9:00AM - 8:00PM
                                    </li>
                                </ul>

                                <div className="social-icons">
                                    <Link to="#" className="social-icon social-instagram icon-instagram" target="_blank" title="Instagram"></Link>
                                    <Link to="#" className="social-icon social-twitter icon-twitter" target="_blank" title="Twitter"></Link>
                                    <Link to="#" className="social-icon social-facebook icon-facebook" target="_blank" title="Facebook"></Link>
                                </div>
                            </div>
                        </div>

                        <div className="col-lg-9 col-md-8">
                            <div className="widget widget-newsletter">
                                <h4 className="widget-title">Subscribe newsletter</h4>
                                <div className="row">
                                    <div className="col-lg-6 col-md-12">
                                        <p>Get all the latest information on Events, Sales and Offers. Sign up for newsletter today</p>
                                    </div>

                                    <div className="col-lg-6 col-md-12">
                                        <form action="#" className="d-flex mb-0 w-100">
                                            <input type="email" className="form-control mb-0" placeholder="Email address" required />

                                            <input type="submit" className="btn btn-primary shadow-none" value="Subscribe" />
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-sm-6">
                                    <div className="widget">
                                        <h4 className="widget-title">Customer Service</h4>

                                        <ul className="links link-parts row mb-0">
                                            <div className="link-part col-lg-6 col-md-12">
                                                <li><Link to={ `${ process.env.PUBLIC_URL }/documentation` }>Help & FAQs</Link></li>
                                                <li><Link to="#">Order Tracking</Link></li>
                                                <li><Link to="#">Shipping & Delivery</Link></li>
                                            </div>
                                            <div className="link-part col-lg-6 col-md-12">
                                                <li><Link to="#">Orders History</Link></li>
                                                <li><Link to="#">Advanced Search</Link></li>
                                                <li><Link to="#" className="login-link">Login</Link></li>
                                            </div>
                                        </ul>
                                    </div>
                                </div>

                                <div className="col-sm-6">
                                    <div className="widget">
                                        <h4 className="widget-title">About Us</h4>

                                        <ul className="links link-parts row mb-0">
                                            <div className="link-part col-lg-6 col-md-12">
                                                <li><Link to={ `${ process.env.PUBLIC_URL }/pages/about` }>About Us</Link></li>
                                                <li><Link to="#">Corporate Sales</Link></li>
                                                <li><Link to="#">Careers</Link></li>
                                            </div>
                                            <div className="link-part col-lg-6 col-md-12">
                                                <li><Link to="#">Community</Link></li>
                                                <li><Link to="#">Investor Relations</Link></li>
                                            </div>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container">
                <div className="footer-bottom d-flex justify-content-between align-items-center flex-wrap">
                    <p className="footer-copyright py-3 pr-4 mb-0">&copy; Porto eCommerce.  { new Date().getFullYear() }.  All Rights Reserved</p>
                    <img src={ `${ process.env.PUBLIC_URL }/assets/images/demo/payments.png` } alt="payment methods" className="footer-payments py-3" />
                </div>
            </div>
        </footer>
    )
}

export default React.memo( Footer );