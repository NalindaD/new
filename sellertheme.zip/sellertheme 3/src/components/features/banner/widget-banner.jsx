import React from 'react';
import { Link } from 'react-router-dom';

const WidgetBanner = ( { addClass = '', src } ) => (
    <div className={ `widget widget-banner ${ addClass }` }>
        <div className="banner banner-image">
            <Link to="#">
                <img src={ `${ process.env.PUBLIC_URL }/${ src }` } alt="Banner Desc" width="250" height="317" />
            </Link>
        </div>
    </div>
)

export default WidgetBanner;