import React from 'react';
import { connect } from 'react-redux';

import ProductTypeFive from '../features/product/product-type-five';
import Carousel from '../features/carousel';

import { productFilter } from '../../utils';
import { owlSetting1 } from '../../utils/settings';

function FeaturedCollection( props ) {
    let products = productFilter( props.products, "featured" );

    return (
        <div className="products-section bg-gray">
            <div className="container">
                <h2 className="section-title">Featured Products</h2>
                <Carousel addClass="products-slider owl-theme dots-top" settings={ owlSetting1 }>
                    {
                        products.map( ( item, index ) => (
                            <ProductTypeFive addClass="inner-quickview inner-icon" product={ item } key={ "product" + index } />
                        ) )
                    }
                </Carousel>
            </div>
        </div>
    )
}

const mapStateToProps = ( state, props ) => {
    return {
        products: state.data.products ? state.data.products : []
    }
}

export default connect( mapStateToProps, {} )( FeaturedCollection );